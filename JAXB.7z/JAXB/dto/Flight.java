package com.mindtree.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "Flights", namespace = "http://www.mindtree.com/Flights")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Flights", propOrder = { "id", "flightCode", "cost", "departureDate", "fromAirPort", "toAirPort",
		"availableSeats", "planeType", "totalSeats" })
public class Flight {
	private int id;
	private String flightCode;
	private double cost;
	private String departureDate;
	private String fromAirPort;
	private String toAirPort;
	private int availableSeats;
	private String planeType;
	private double totalSeats;

	public Flight() {
		super();
	}

	public Flight(int id, String flightCode, double cost, String departureDate, String fromAirPort, String toAirPort,
			int availableSeats, String planeType, double totalSeats) {
		super();
		this.id = id;
		this.flightCode = flightCode;
		this.cost = cost;
		this.departureDate = departureDate;
		this.fromAirPort = fromAirPort;
		this.toAirPort = toAirPort;
		this.availableSeats = availableSeats;
		this.planeType = planeType;
		this.totalSeats = totalSeats;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFlightCode() {
		return flightCode;
	}

	public void setFlightCode(String flightCode) {
		this.flightCode = flightCode;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public String getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

	public String getFromAirPort() {
		return fromAirPort;
	}

	public void setFromAirPort(String fromAirPort) {
		this.fromAirPort = fromAirPort;
	}

	public String getToAirPort() {
		return toAirPort;
	}

	public void setToAirPort(String toAirPort) {
		this.toAirPort = toAirPort;
	}

	public int getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

	public String getPlaneType() {
		return planeType;
	}

	public void setPlaneType(String planeType) {
		this.planeType = planeType;
	}

	public double getTotalSeats() {
		return totalSeats;
	}

	public void setTotalSeats(double totalSeats) {
		this.totalSeats = totalSeats;
	}

	@Override
	public String toString() {
		return "FlightsApp [id=" + id + ", flightCode=" + flightCode + ", cost=" + cost + ", departureDate="
				+ departureDate + ", fromAirPort=" + fromAirPort + ", toAirPort=" + toAirPort + ", availableSeats="
				+ availableSeats + ", planeType=" + planeType + ", totalSeats=" + totalSeats + "]";
	}

}

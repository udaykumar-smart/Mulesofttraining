package com.mindtree.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "Address", namespace = "http://www.example.org/Customers")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Address", propOrder = { "city", "buildingName", "street", "pincode", "state" })
public class Address {
	private String city;
	private String buildingName;
	private String street;
	private String pincode;
	private String state;

	public Address() {
		super();

	}

	public Address(String city, String buildingName, String street, String pincode, String state) {
		super();
		this.city = city;
		this.buildingName = buildingName;
		this.street = street;
		this.pincode = pincode;
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

}

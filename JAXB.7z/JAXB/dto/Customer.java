package com.mindtree.dto;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlAccessType;

@XmlRootElement(name = "Customer", namespace = "http://www.example.org/Customers")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Customer", propOrder = { "CustomerID", "FullName", "phone" })
public class Customer {
	private int CustomerID;
	private String FullName;
	private String phone;

	public int getCustomerID() {
		return CustomerID;
	}

	public Customer() {
		super();
	}

	public Customer(int customerID, String fullName, String phone) {
		super();
		CustomerID = customerID;
		FullName = fullName;
		this.phone = phone;
	}

	public String getFullName() {
		return FullName;
	}

	public void setFullName(String fullName) {
		FullName = fullName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setCustomerID(int customerID) {
		CustomerID = customerID;
	}
}

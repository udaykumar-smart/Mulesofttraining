package com.mindtree.ui;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.mindtree.dto.Address;
import com.mindtree.dto.Customer;

public class UnMarshalDemo {

	public static void main(String[] args) throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(Customer.class);
		Unmarshaller unmarshall = jaxbContext.createUnmarshaller();
		Customer cust = (Customer) unmarshall.unmarshal(new File("src/main/resources/customers.xml"));
		System.out.println(cust.getCustomerID() + "," + cust.getFullName() + "," + cust.getPhone());

		JAXBContext jaxbContext1 = JAXBContext.newInstance(Address.class);
		Unmarshaller unmarshall1 = jaxbContext1.createUnmarshaller();
		Address address = (Address) unmarshall1.unmarshal(new File("src/main/resources/add.xml"));
		System.out.println(address.getCity() + "," + address.getBuildingName() + "," + address.getStreet() + ","
				+ address.getPincode() + "," + address.getState());

	}

}

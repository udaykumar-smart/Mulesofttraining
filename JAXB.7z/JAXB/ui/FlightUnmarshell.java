package com.mindtree.ui;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.mindtree.dto.Flight;

public class FlightUnmarshell {

	public static void main(String[] args) throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(Flight.class);

		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

		Flight flights = (Flight) unmarshaller.unmarshal(new File("src/main/resources/FlightOutput.xml"));
		System.out.println(flights.getId() + "," + flights.getFlightCode() + "," + flights.getCost() + ","
				+ flights.getDepartureDate() + "," + flights.getFromAirPort() + "," + flights.getToAirPort() + ","
				+ flights.getAvailableSeats() + "," + flights.getPlaneType() + "," + flights.getTotalSeats());
	}

}

package com.mindtree.ui;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.mindtree.dto.Address;
import com.mindtree.dto.Customer;

public class MarshalDemo {

	public static void main(String[] args) throws JAXBException {
		Customer customer = new Customer(50013, "UDAY KUMAR", "9676326184");
		JAXBContext jaxbContext = JAXBContext.newInstance(Customer.class);
		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(customer, System.out);
		marshaller.marshal(customer, new File("src/main/resources/customers.xml"));

		Address address = new Address("VIJAYAWADA", "HAM", "HAMEED STREET", "520012", "VIJAYAWADA");
		JAXBContext jaxbContext1 = JAXBContext.newInstance(Address.class);
		Marshaller marshaller1 = jaxbContext1.createMarshaller();
		marshaller1.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller1.marshal(address, System.out);
		marshaller1.marshal(address, new File("src/main/resources/add.xml"));

	}

}

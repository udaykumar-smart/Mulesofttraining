package com.mindtree.ui;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.mindtree.dto.Flight;

public class FlightMarshell {

	public static void main(String[] args) throws JAXBException {
		Flight flights1 = new Flight(101, "ATF7869", 17693.5, "16 Aug 2021", "UK", "HYD", 8, "AirIngo 778", 250);

		Flight flights2 = new Flight(102, "ATF7870", 27693.5, "15 Aug 2021", "JAPAN", "HYD", 8, "Boieng 888", 150);

		Flight flights3 = new Flight(103, "ATF7871", 37693.5, "14 Aug 2021", "USA", "HYD", 8, "INDIFO 9878", 100);

		JAXBContext jaxbContext = JAXBContext.newInstance(Flight.class);

		Marshaller marshaller = jaxbContext.createMarshaller();

		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

		marshaller.marshal(flights1, System.out);

		marshaller.marshal(flights1, new File("src/main/resources/FlightOutput.xml"));
		marshaller.marshal(flights2, new File("src/main/resources/FlightOutput.xml"));
		marshaller.marshal(flights3, new File("src/main/resources/FlightOutput.xml"));

	}

}

package com.mindtree.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mindtree.dto.Customer;
//import com.mysql.jdbc.Driver;

public class CustomerDaoImpl {
	Customer customer = new Customer();

	public Connection getConnection() {

		Connection connection = null;
		try {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mulesoft", "root", "root");

			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return connection;
	}

	private void closeConnection(Connection connection) {
		try {
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int insertCustomer(Customer customer) {
		int result = 0;
		Connection connection = getConnection();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into customers(customerId, fullName, phone) values(?,?,?)");

			preparedStatement.setInt(1, Integer.parseInt(customer.getCustomerId()));
			preparedStatement.setString(2, customer.getFullName());
			preparedStatement.setString(3, customer.getPhone());
			result = preparedStatement.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			closeConnection(connection);
		}
		return result;
	}

	public Customer getCustomerById(int customerId) {
		Customer customer = null;
		Connection connection = getConnection();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from customers where customerId = ?");
			preparedStatement.setInt(1, customerId);

			ResultSet resultSet = preparedStatement.executeQuery();

			resultSet.next();
			customer = new Customer(resultSet.getInt("customerid") + "", resultSet.getString("fullName"),
					resultSet.getString("phone"));
			resultSet.close();
			preparedStatement.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			closeConnection(connection);
		}
		return customer;

	}

	public ArrayList<Customer> getAllCustomers() {
		ArrayList<Customer> customers = new ArrayList<Customer>();
		Connection connection = getConnection();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from customers");

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				Customer customer = new Customer(resultSet.getInt("customerid") + "", resultSet.getString("fullName"),
						resultSet.getString("phone"));
				customers.add(customer);
			}

			resultSet.close();
			preparedStatement.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			closeConnection(connection);
		}
		return customers;

	}

	public int deleteCustomer(int customerId) {
		int result = 0;
		Connection connection = getConnection();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("delete from customers where customerId = ?");
			preparedStatement.setInt(1, customerId);
			result = preparedStatement.executeUpdate();
			preparedStatement.close();
			result = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(connection);
		}
		return result;
	}

	public int updateCustomer(int customerId, String newName, String newNumber) {
		int result = 0;
		Connection connection = getConnection();

		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("update customers set fullName=?,phone=? where customerId=?");
			preparedStatement.setString(1, newName);
			preparedStatement.setString(2, newNumber);
			preparedStatement.setInt(3, customerId);
			result = preparedStatement.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			closeConnection(connection);
		}

		return result;
	}

}
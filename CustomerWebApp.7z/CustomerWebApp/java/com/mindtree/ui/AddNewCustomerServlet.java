package com.mindtree.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mindtree.dao.CustomerDaoImpl;
import com.mindtree.dto.Customer;


public class AddNewCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String customerId = request.getParameter("customerId");
		String fullName = request.getParameter("fullName");
		String phone = request.getParameter("phone");
		
		Customer customer= new Customer(customerId, fullName, phone);
		
		CustomerDaoImpl customerDaoImpl = new CustomerDaoImpl();
		
		int result = customerDaoImpl.insertCustomer(customer);
		
		
		PrintWriter out = response.getWriter(); 
		
		
		if (result == 1) {
			out.println("<html><body>Customer is inserted.<br/>");
			out.println("<a href='index.html'>Home Page</a></body></html>");
		}else {
			out.println("Customer is not inserted. Try later.<br/>");
			out.println("<a href='index.html'>Home Page</a>");
		}
		
		
	}


}
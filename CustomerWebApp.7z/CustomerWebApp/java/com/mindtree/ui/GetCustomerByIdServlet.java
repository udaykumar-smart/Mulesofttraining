package com.mindtree.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mindtree.dao.CustomerDaoImpl;
import com.mindtree.dto.Customer;



public class GetCustomerByIdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		CustomerDaoImpl CustomerDaoImpl = new CustomerDaoImpl();
		int customerId = Integer.parseInt(request.getParameter("customerId"));
		Customer customer = CustomerDaoImpl.getCustomerById(customerId);
		PrintWriter out = response.getWriter();
		out.print("<html><body>");
		if (customer != null) {
			out.print("<table border='2' width='100%'");
			out.print("<tr><th>CustomerId</th>"+"<th>FullName</th>"+"<th>Phone</th></tr>");
			out.print("<tr><td>"+customer.getCustomerId()+"</td><td>"+customer.getFullName()+"</td><td>"+customer.getPhone()+"</td></tr>");
		
			out.print("</table>");
			out.println("<a href='index.html'>Home Page</a>");
			out.print("</html></body>");
		} else {
			out.println("<a href='index.html'>Home Page</a>");
			out.print("</html></body>");
		}
		
		
	}
	

	
	/*
	 * out.print("<table border='2' width='100%'");
	 * out.print("<tr>CustomerId<td>"+"</td>FullName<td>"+"</td>Phone<td>"+"</tr>");
	 * 
	 * for(Customer e:list) {
	 * out.print("<tr><td>"+e.getCustomerId()+"</td><td>"+e.getFullName()+
	 * "</td><td>"+e.getPhone()+"</tr>"); } out.print("</table>");
	 */

}

package com.mindtree.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mindtree.dao.CustomerDaoImpl;
import com.mindtree.dto.Customer;


public class GetAllCustomersServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		CustomerDaoImpl CustomerDaoImpl=new CustomerDaoImpl();
		List<Customer> list=CustomerDaoImpl.getAllCustomers();
		out.print("<html><body>");
		out.print("<table border='2' width='100%'");
		out.print("<tr><th>CustomerId</th>"+"<th>FullName</th>"+"<th>Phone</th></tr>");
		for(Customer e:list) 
		{	
		out.print("<tr><td>"+e.getCustomerId()+"</td><td>"+e.getFullName()+"</td><td>"+e.getPhone()+"</td></tr>");
		}
		out.print("</table>");
		out.println("<a href='index.html'>Home Page</a>");
		out.print("</html></body>");
		out.close();
	}

	

}

package com.mindtree.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mindtree.dao.CustomerDaoImpl;
import com.mindtree.dto.Customer;

public class DeleteCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		CustomerDaoImpl CustomerDaoImpl = new CustomerDaoImpl();
		int customerId = Integer.parseInt(request.getParameter("customerId"));
		int result = CustomerDaoImpl.deleteCustomer(customerId);

		PrintWriter out = response.getWriter();

		if (result == 1) {
			out.println("<html><body>customer is deleted.<br/>");
			out.println("<a href='index.html'>Home Page</a></body></html>");
		} else {
			out.println("customer is not deleted. Try Again.<br/>");
			out.println("<a href='index.html'>Home Page</a>");
		}
	}

}
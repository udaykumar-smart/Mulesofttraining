package com.mindtree.ui;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mindtree.dao.CustomerDaoImpl;
import com.mindtree.dto.Customer;

public class UpdateCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		int customerId = Integer.parseInt(request.getParameter("customerId"));
		String fullName = request.getParameter("fullName");
		String phone = request.getParameter("phone");

		CustomerDaoImpl customerDaoImpl = new CustomerDaoImpl();

		int result = customerDaoImpl.updateCustomer(customerId, fullName, phone);
		PrintWriter out = response.getWriter();

		if (result == 1) {
			out.println("<html><body>Customer is updated.<br/>");
			out.println("<a href='index.html'>Home Page</a></body></html>");
		} else {
			out.println("Customer is not updated. Try later.<br/>");
			out.println("<a href='index.html'>Home Page</a>");
		}

}
	
}

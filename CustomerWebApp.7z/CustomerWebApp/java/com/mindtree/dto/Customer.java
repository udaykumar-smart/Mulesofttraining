package com.mindtree.dto;

public class Customer {
	private  String customerId;
	private String fullName;
	private String phone;
	
	
	public Customer() {
		super();
	}
	public Customer(String customerId, String fullName, String phone) {
		super();
		this.customerId = customerId;
		this.fullName = fullName;
		this.phone = phone;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	

}
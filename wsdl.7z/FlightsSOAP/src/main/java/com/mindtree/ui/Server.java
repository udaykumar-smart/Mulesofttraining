package com.mindtree.ui;

import javax.xml.ws.Endpoint;

import com.mindtree.service.FlightServiceImpl;

public class Server {

	public static void main(String[] args) {
		FlightServiceImpl flightServiceImpl = new FlightServiceImpl();
		
		String url = "http://localhost:9099/FlightService";
		
		Endpoint.publish(url, flightServiceImpl);
		//server 9090 /CustomerService
		//JAX-WS code
		
		System.out.println("Server started at port number 9099");
	}

}

/*private int id;
	private String flightCode;
	private double cost;
	private String departureDate;
	private String fromAirPort;
	private String toAirPort;
	private int availableSeats;
	private String planeType;
	private int totalSeats;
id, flightCode, cost,departureDate,fromAirPort,toAirPort,availableSeats,planeType,totalSeats
getId
getFlightCode
getCost
getDepartureDate
getFromAirPort
getToAirPort
getAvailableSeats
getPlaneType
getTotalSeats
*/

package com.mindtree.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mindtree.dto.Flight;

public class FlightDaoImpl {
	public Connection getConnection() {

		Connection connection = null;
		try {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mulesoft", "root", "root");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return connection;
	}

	private void closeConnection(Connection connection) {
		try 
		{
			connection.close();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public int insertFlight(Flight flight) {
		int result = 0;
		Connection connection = getConnection();
		
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into flights(id, flightCode, cost,departureDate,fromAirPort,"
							+ "toAirPort,availableSeats,planeType,totalSeats) values(?,?,?,?,?,?,?,?,?)");
			preparedStatement.setInt(1, flight.getId());
			preparedStatement.setString(2, flight.getFlightCode());
			preparedStatement.setDouble(3, flight.getCost());
			preparedStatement.setString(4, flight.getDepartureDate());
			preparedStatement.setString(5, flight.getFromAirPort());
			preparedStatement.setString(6, flight.getToAirPort());
			preparedStatement.setInt(7, flight.getAvailableSeats());
			preparedStatement.setString(8, flight.getPlaneType());
			preparedStatement.setInt(9, flight.getTotalSeats());
			result = preparedStatement.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			closeConnection(connection);
		}
		return result;
	}
	
	public Flight getFlightById(int Id) {
		Flight flight = null;
		Connection connection = getConnection();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from flights where Id = ?");
			preparedStatement.setInt(1, Id);

			ResultSet resultSet = preparedStatement.executeQuery();

			resultSet.next();
			flight = new Flight(resultSet.getInt("id"), resultSet.getString("flightCode"), 
					resultSet.getDouble("cost"),resultSet.getString("departureDate"),resultSet.getString("fromAirPort"), 
					resultSet.getString("toAirPort"),resultSet.getInt("availableSeats"),
					resultSet.getString("planeType"),resultSet.getInt("totalSeats"));
			resultSet.close();
			preparedStatement.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			closeConnection(connection);
		}
		return flight;

	}
	
	public ArrayList<Flight> getAllFlights() {
		ArrayList<Flight> flights = new ArrayList<Flight>();
		Connection connection = getConnection();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from flights");

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				Flight flight = new Flight(resultSet.getInt("id"), resultSet.getString("flightCode"), 
						resultSet.getDouble("cost"),resultSet.getString("departureDate"),resultSet.getString("fromAirPort"), 
						resultSet.getString("toAirPort"),resultSet.getInt("availableSeats"),
						resultSet.getString("planeType"),resultSet.getInt("totalSeats"));
				flights.add(flight);
			}

			resultSet.close();
			preparedStatement.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			closeConnection(connection);
		}
		return flights;

	}

	public int deleteFlight(int Id) {
		int result = 0;
		Connection connection = getConnection();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("delete from flights where Id = ?");
			preparedStatement.setInt(1, Id);
			result = preparedStatement.executeUpdate();
			preparedStatement.close();
			result = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(connection);
		}
		return result;
	}

	public int updateFlight(int id, String flightCode, double cost, String departureDate, String fromAirPort, String toAirPort,
			int availableSeats, String planeType, int totalSeats) {
		int result = 0;
		Connection connection = getConnection();

		try {
			PreparedStatement preparedStatement = connection.prepareStatement
					("update flights set flightCode=?,departureDate=?,"
							+ "availableSeats=?,planeType=?,totalSeats=? where id=?");
			/*
			PreparedStatement preparedStatement = connection.prepareStatement
					("update flights set flightCode=?,cost=?,departureDate=?,fromAirPort=?,"
							+ "toAirPort=?,availableSeats=?,planeType=?,totalSeats=? where id=?");
							*/
			preparedStatement.setInt(1, id);
			preparedStatement.setString(2, flightCode);
			preparedStatement.setDouble(3, cost);
			preparedStatement.setString(4, departureDate);
			preparedStatement.setString(5, fromAirPort);
			preparedStatement.setString(6, toAirPort);
			preparedStatement.setInt(7, availableSeats);
			preparedStatement.setString(8, planeType);
			preparedStatement.setInt(9, totalSeats);
			result = preparedStatement.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			closeConnection(connection);
		}

		return result;
	}

}

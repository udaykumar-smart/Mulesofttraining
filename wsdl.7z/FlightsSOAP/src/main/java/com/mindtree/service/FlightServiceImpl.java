package com.mindtree.service;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebService;

import com.mindtree.dao.FlightDaoImpl;
import com.mindtree.dto.Flight;

@WebService(endpointInterface = "com.mindtree.service.FlightService")
public class FlightServiceImpl implements FlightService {

	private FlightDaoImpl flightDaoImpl;

	public FlightServiceImpl() {
		flightDaoImpl = new FlightDaoImpl();
	}

	@Override
	public boolean addFlight(int id, String flightCode, Double cost, String departureDate, String fromAirPort,
			String toAirPort, int availableSeats, String planeType, int totalSeats) {
		Flight flight = new Flight(id, flightCode, cost, departureDate, fromAirPort, toAirPort, availableSeats,
				planeType, totalSeats);

		int result = flightDaoImpl.insertFlight(flight);

		if (result == 1) {
			return true;
		}

		return false;
	}

	@Override
	public Flight getFlightById(int Id) {

		Flight flight = flightDaoImpl.getFlightById(Id);

		return flight;
	}

	@Override
	public ArrayList<Flight> getAllFlights() {

		List<Flight> list = flightDaoImpl.getAllFlights();

		return (ArrayList<Flight>) list;
	}

	@Override
	public int deleteFlight(int Id) {

		int deleteflight = flightDaoImpl.deleteFlight(Id);

		return deleteflight;
	}

	@Override
	public int updateFlight(int id, String flightCode, Double cost, String departureDate, String fromAirPort,
			String toAirPort, int availableSeats, String planeType, int totalSeats) {
		int updateflight = flightDaoImpl.updateFlight(id, flightCode, cost, departureDate, fromAirPort, toAirPort,
				availableSeats, planeType, totalSeats);
		return updateflight;
	}

}

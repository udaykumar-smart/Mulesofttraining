package com.mindtree.service;

import java.util.ArrayList;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import com.mindtree.dto.Flight;


@WebService(name = "Flights", targetNamespace = "https://www.mindtree.com/FS")
public interface FlightService {

	@WebMethod(operationName = "addFlight")
	public @WebResult(name = "result") boolean addFlight(@WebParam(name = "Id") int id,
			@WebParam(name = "flightCode") String flightCode, 
			@WebParam(name = "cost") Double cost,
			@WebParam(name = "departureDate") String departureDate,
			@WebParam(name = "fromAirPort") String fromAirPort,
			@WebParam(name = "toAirPort") String toAirPort,
			@WebParam(name = "availableSeats") int availableSeats,
			@WebParam(name = "planeType") String planeType,
			@WebParam(name = "totalSeats") int totalSeats);

	@WebMethod(operationName = "getFlightById")
	public @WebResult(name = "Flight") Flight getFlightById(@WebParam(name = "Id") int id);

	@WebMethod(operationName = "getAllFlights")
	// public @WebResult(name = "Customer") Customer getAllCustomers(@WebParam(name
	// = "AllCustomers"));
	public @WebResult(name = "Flight") ArrayList<Flight> getAllFlights();

	@WebMethod(operationName = "deleteFlight")
	public @WebResult(name = "delete") int deleteFlight(@WebParam(name = "Id") int id);

	@WebMethod(operationName = "updateFlight")
	public @WebResult(name = "updateFlightId") int updateFlight(@WebParam(name = "Id") int id,
			@WebParam(name = "flightCode") String flightCode, 
			@WebParam(name = "cost") Double cost,
			@WebParam(name = "departureDate") String departureDate,
			@WebParam(name = "fromAirPort") String fromAirPort,
			@WebParam(name = "toAirPort") String toAirPort,
			@WebParam(name = "availableSeats") int availableSeats,
			@WebParam(name = "planeType") String planeType,
			@WebParam(name = "totalSeats") int totalSeats);

	
}
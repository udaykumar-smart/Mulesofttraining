package com.mindtree.service;

import java.util.ArrayList;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import com.mindtree.dto.Customer;

@WebService(name = "Customers", targetNamespace = "https://www.mindtree.com/CS")
public interface CustomerService {

	@WebMethod(operationName = "addCustomer")
	public @WebResult(name = "result") boolean addCustomer(@WebParam(name = "customerId") int customerId,
			@WebParam(name = "fullName") String fullName, 
			@WebParam(name = "phone") String phone);

	@WebMethod(operationName = "getCustomerById")
	public @WebResult(name = "Customer") Customer getCustomerById(@WebParam(name = "customerId") int customerId);

	@WebMethod(operationName = "getAllCustomers")
	// public @WebResult(name = "Customer") Customer getAllCustomers(@WebParam(name
	// = "AllCustomers"));
	public @WebResult(name = "Customer") ArrayList<Customer> getAllCustomers();

	@WebMethod(operationName = "deleteCustomer")
	public @WebResult(name = "delete") int deleteCustomer(@WebParam(name = "customerId") int customerId);

	@WebMethod(operationName = "updateCustomer")
	public @WebResult(name = "updatecustomerId") int updateCustomer(@WebParam(name = "customerId") int customerId,
			@WebParam(name = "updatefullName") String fullName, 
			@WebParam(name = "updatephone") String phone);

}
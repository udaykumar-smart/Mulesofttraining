package com.mindtree.service;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebService;

import com.mindtree.dao.CustomerDaoImpl;
import com.mindtree.dto.Customer;

@WebService(endpointInterface = "com.mindtree.service.CustomerService")
public class CustomerServiceImpl implements CustomerService {

	
	private CustomerDaoImpl customerDaoImpl;
	
	public CustomerServiceImpl() {
		customerDaoImpl = new CustomerDaoImpl();
	}
	
	
	@Override
	public boolean addCustomer(int customerId, String fullName, String phone) {
		
		Customer customer = new Customer(customerId+"", fullName, phone);
		
		int result = customerDaoImpl.insertCustomer(customer);
		
		if(result == 1) {
			return true;
		}
		
		return false;
	}

	@Override
	public Customer getCustomerById(int customerId) {
		
		Customer customer = customerDaoImpl.getCustomerById(customerId);
		
		return customer;
	}
	
	@Override
	public ArrayList<Customer> getAllCustomers() {
		
		List<Customer> list = customerDaoImpl.getAllCustomers();
		
		return (ArrayList<Customer>) list;
	}
	
	@Override
	public int deleteCustomer(int customerId) {
		
		int deletecustomer = customerDaoImpl.deleteCustomer(customerId);
		
		return deletecustomer;
	}
	
	@Override
	public int updateCustomer(int customerId,String fullName,String phone) {
		
		int updatecustomer = customerDaoImpl.updateCustomer(customerId,fullName,phone);
		
		return updatecustomer;
	}
	
}

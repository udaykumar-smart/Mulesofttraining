package com.mindtree.dto;

/*import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
*/
//@XmlRootElement(name = "Customer")
//@XmlAccessorType(XmlAccessType.FIELD)
//@XmlType(name = "cust")
public class Customer {

	// @XmlElement(name = "CID", type= Integer.class)
	private String customerId;
	private String fullName;
	private String phone;

	public Customer() {
		super();
	}

	public Customer(String customerId, String fullName, String phone) 
	{
		super();
		this.customerId = customerId;
		this.fullName = fullName;
		this.phone = phone;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

}

package com.mindtree.ui;

import javax.xml.ws.Endpoint;

import com.mindtree.service.CustomerServiceImpl;

public class Server {

	public static void main(String[] args) {
		CustomerServiceImpl customerServiceImpl = new CustomerServiceImpl();
		
		String url = "http://localhost:9090/CustomerService";
		
		Endpoint.publish(url, customerServiceImpl);
		//server 9090 /CustomerService
		//JAX-WS code
		
		System.out.println("Server started at port number 9090");
	}

}
